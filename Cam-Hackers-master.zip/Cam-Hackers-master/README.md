# Cam-Hackers

Hack Cameras

<h3> Mode Of Execution: </h3>

* apt-get install python3

* apt-get install git

* git clone https://github.com/AngelSecurityTeam/Cam-Hackers

* pip3 install requests

* cd Cam-Hackers

* python3 cam-hackers.py

# CAM-HACKERS

<img src="https://github.com/AngelSecurityTeam/Cam-Hackers/blob/master/camfoto.png">

# CAM-HACKERS

<img src="https://github.com/AngelSecurityTeam/Cam-Hackers/blob/master/camfoto2.png">

<h3> Paypal donations: </h3>

* https://www.paypal.me/AngelSecurityTeam
